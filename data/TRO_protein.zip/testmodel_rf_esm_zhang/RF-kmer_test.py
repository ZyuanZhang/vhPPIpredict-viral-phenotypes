import os
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedShuffleSplit, GridSearchCV, train_test_split
from sklearn.preprocessing import label_binarize

# 读取特征文件，这里假设你的k-mer特征文件路径及格式
# 你可以按需修改路径和文件名
k_values = [3, 4, 5]

# 读取标签
df_label = pd.read_csv('../../../../../data/final_214_genome_proteome_label.csv')
df_label.rename(columns={'Taxid': 'Taxid'}, inplace=True)
df_label.dropna(subset=['Tr.primary'], inplace=True)

df_kmer = pd.read_csv(f'../../data/213esm.csv').rename(columns={'VirusID': 'Taxid'})

# 合并标签与特征
df = pd.merge(df_label[['Taxid', 'Tr.primary']], df_kmer, on='Taxid')
df = df.dropna(subset=['Tr.primary'])
df = df[df['Taxid'] != 3052490]  # 按需过滤

df.set_index('Taxid', inplace=True)
taxids = df.index.values
print(f"数据大小: {df.shape}")

X = df.drop(columns=['Tr.primary']).values
y = np.array(df['Tr.primary'])

# 所有类别
classes = np.unique(y)

# 评估指标字典
metrics_list = {
    'accuracy': [],
    'precision_macro': [],
    'recall_macro': [],
    'f1_macro': [],
    'auc_macro': []
}

# 100次随机分层划分
sss = StratifiedShuffleSplit(n_splits=100, test_size=0.15, random_state=42)

param_grid = {
    'n_estimators': [50, 100, 200, 300, 500],
    'max_depth': [None, 10, 15, 20, 25],
}

outpath = f"./result/test/rf_esm/Trprimary"
os.makedirs(outpath, exist_ok=True)

for i, (train_val_index, test_index) in enumerate(sss.split(X, y)):
    if i % 10 == 0:
        print(f"Processing split {i + 1}/100", flush=True)

    X_train_val, X_test = X[train_val_index], X[test_index]
    y_train_val, y_test = y[train_val_index], y[test_index]

    # # 从训练+验证集中划出验证集
    # X_train, X_val, y_train, y_val, taxid_train, taxid_val = train_test_split(
    #     X_train_val, y_train_val, taxids[train_val_index],
    #     test_size=0.1765,
    #     stratify=y_train_val,
    #     random_state=42
    # )

    grid_search = GridSearchCV(
        RandomForestClassifier(random_state=train_val_index[0]),
        param_grid,
        cv=5,
        scoring='roc_auc_ovr_weighted',
        n_jobs=8
    )
    grid_search.fit(X_train_val, y_train_val)
    best_model = grid_search.best_estimator_

    # 验证集预测
    y_pred = best_model.predict(X_test)
    y_prob = best_model.predict_proba(X_test)
    y_val_onehot = label_binarize(y_test, classes=best_model.classes_)

    metrics_list['accuracy'].append(accuracy_score(y_test, y_pred))
    metrics_list['precision_macro'].append(precision_score(y_test, y_pred, average='macro', zero_division=0))
    metrics_list['recall_macro'].append(recall_score(y_test, y_pred, average='macro', zero_division=0))
    metrics_list['f1_macro'].append(f1_score(y_test, y_pred, average='macro', zero_division=0))

    try:
        auc_micro = roc_auc_score(y_val_onehot, y_prob, average='macro', multi_class='ovr')
    except ValueError:
        auc_micro = np.nan
    metrics_list['auc_macro'].append(auc_micro)

    # 保存每个样本的概率预测
    prob_df = pd.DataFrame(y_prob, columns=[f'prob_{c}' for c in classes])
    # prob_df['taxid'] = taxid_val
    prob_df['true'] = y_test
    prob_df['pred'] = y_pred
    prob_df.to_csv(f"{outpath}/probs_split{i}.csv", index=False)

# 保存评价指标结果
result_df = pd.DataFrame(metrics_list)
summary = result_df.describe().loc[['mean', 'std']]

result_df.to_csv(f"{outpath}/result_test.csv", index=False)
summary.to_csv(f"{outpath}/summary_test.csv")
